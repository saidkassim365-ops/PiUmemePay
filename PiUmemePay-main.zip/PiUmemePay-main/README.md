# PiUmemePay
Pi UmemePay# The fastest and easiest way for the world to pay for electricity using the Pi cryptocurrency. *Long description:* Pi UmemePay is a decentralized application built on the Pi Network ecosystem that allows users around the world to easily.
